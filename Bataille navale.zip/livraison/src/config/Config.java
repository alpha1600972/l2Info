package config;

public final class Config {
	private Config () {
		
	}
	public static final int GRID_Cols=10;
	public static final int GRID_Rows=10;

	public static final int [ ] sizeShip = {5,4,3,3,2};

}
// classe config
// modif