package model;
public enum CellState {
	BLANK,
	HIT,
	MISSED,
}
