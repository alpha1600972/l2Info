package util;

public interface ListenableModel {
	public  void addListening(ListeningModel  e);
	public void removeListening(ListeningModel  e);

}
