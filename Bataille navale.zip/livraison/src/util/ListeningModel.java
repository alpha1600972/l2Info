package util;

public interface ListeningModel {
	public void modeleMIsAJour(Object source, Object notification);
}
