package util.notifications;

public enum ShipNotification {
    SHIP_DESTROYED,
    SHIP_VISIBILITY_CHANGED
}
