package util.notifications;

public enum PlayerNotification {
    FLEET_CREATED
}
