package util.notifications;

public enum CellNotification {
    STATE_CHANGED
}
