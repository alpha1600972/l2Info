package util.notifications;

public enum GridNotification {
    
}
