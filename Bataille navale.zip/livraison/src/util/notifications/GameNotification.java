package util.notifications;

public enum GameNotification {
    GAME_STARTED,
    HUMAN_FLEET_CREATED,
    RANDOM_FLEET_CREATED,
}
