package views;

public final class FrameSize {
	public static final int HEAD_HEIGHT = 500;
	public static final int HEAD_WIDTH = 500;
}
