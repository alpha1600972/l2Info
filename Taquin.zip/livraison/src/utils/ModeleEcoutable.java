package utils;

public interface ModeleEcoutable {
	
	 void ajoutEcouteur(EcouteurModele e);
	 void retraitEcouteur(EcouteurModele e); 
		
	
}
