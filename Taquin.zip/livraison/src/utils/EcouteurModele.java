package utils;

/**
 * L'interface EcouteurModele
 */
public interface EcouteurModele {
	
	/**
	 * Methode de mise a jour des ecouteurs
	 * @param source l'objet a metre a jour
	 */
	public void modeleMisAjour(Object source);
}
