package games.players;

/**
 * "Humain" est le nom de la classe représentant les joueurs qui sont des humains
 *elle implemente l'interface Player
 * @author diallo-sow
 * @version 1.0
 * @since 01-09-2022
 */

import java.util.Scanner;

import games.genericgames.Game;

public class Human implements Player{
    private String name;
    private Scanner scan;

    public Human(String name,Scanner scan){
        this.name=name;
        this.scan=scan;

    }

/**
* cette  methode chooseMove prend en argument un objet de Type Game 
* elle permet de demander au joueur quel coup il veut jouer
*elle implemente la methode choosMove de l'interface Player
*elle retourne le coup choisi par le joueur
*/
    @Override
    public int chooseMove(Game game){
        System.out.println("Coups valides:"+game.validMoves());
        int move;
        do {
            System.out.println("veuillez choisir un coup valide : ");
            move = this.scan.nextInt();
        } while (!game.isValid(move));
        return move;
    }

/**
* cette  methode est une redefinition de la methode toString
* elle retourne le nom du joueur

*/
    @Override
    public String toString(){
        return this.name;
    }
}