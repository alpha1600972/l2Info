package games.players;

import gamestests.players.HumanTests;
import gamestests.players.RandomPlayerTests;
import gamestests.players.NegamaxPlayerTests;
import gamestests.players.NegamaxPlayerWithCacheTests;
public class Test{
    public static void main(String[] args) {
        
        boolean ok = true;

        HumanTests humanTester = new HumanTests();
        // Change argument to true in next call to reactivate printing
        ok = ok && humanTester.testChooseMove(false);

        RandomPlayerTests randomTester = new RandomPlayerTests();
        ok = ok && randomTester.testChooseMove();

        NegamaxPlayerTests negamaxTester = new NegamaxPlayerTests();
        ok = ok && negamaxTester.testEvaluate();
        ok = ok && negamaxTester.testChooseMove();

        NegamaxPlayerWithCacheTests negamaxWithCacheTester
        = new NegamaxPlayerWithCacheTests();
        ok = ok && negamaxWithCacheTester.testNimEquals();
        ok = ok && negamaxWithCacheTester.testNimHashCode();
        ok = ok && negamaxWithCacheTester.testTicTacToeEquals();
        ok = ok && negamaxWithCacheTester.testTicTacToeHashCode();
        ok = ok && negamaxWithCacheTester.testEvaluate();
        ok = ok && negamaxWithCacheTester.testChooseMove();

        System.out.println(ok ? "All␣tests␣OK" : "At␣least␣one␣test␣KO");
    }
}