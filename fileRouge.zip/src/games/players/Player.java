package games.players;

/**
* cette  interface Player déclare une seule methode chooseMove prenant en argument un objet de Type Game 
* elle permet de demander au joueur quel coup il veut jouer
*/

import games.genericgames.Game;

public interface Player {

   public int chooseMove(Game game);
}