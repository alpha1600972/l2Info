package games.players;

/**
 * "RandomPlayer" est le nom de la classe représentant les joueurs aléatoires
 *elle implemente l'interface Player
 * @author diallo-sow
 * @version 1.0
 * @since 01-09-2022
 */

import java.util.Random;

import games.genericgames.Game;

public class RandomPlayer implements Player{
    private Random rand;
    public RandomPlayer(Random rand){
        this.rand=rand;
   }

/**
* cette  methode chooseMove prend en argument un objet de Type Game 
*elle implemente la methode choosMove de l'interface Player
*elle retourne un coup tiré de façon aléatoire parmi l'ensemble des coups valides
*/
    @Override
    public int chooseMove(Game game){
        int move=rand.nextInt(game.validMoves().size());
        return game.validMoves().get(move);
    }

/**
* cette  methode est une redefinition de la methode toString
* elle retourne le numéro de joueur aléatoire

*/
    @Override
    public String toString(){
        return "joueur aleatoire n° "+ this.hashCode();
    }

}