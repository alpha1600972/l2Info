package games.players;
import games.genericgames.Game;

import java.util.HashMap;
import java.util.Map;
public class NegamaxPlayerWithCache extends NegamaxPlayer{
    private Map<Game,Integer> cache;//permet de stocker les situations dèja evaluées
    public NegamaxPlayerWithCache(){
        this.cache=new HashMap<>();
    }
    /**
     *elle permet d'evaluer une situation tout en verifiant si la situation existe deja dans "cache" 
     *si la situation est dans le cache elle retourne la valeur associé
     *sinon elle calcule la valeur de la situation et l'ajoute dans "cache"
     */
    @Override
    public int evaluate(Game game){
        if(cache.containsKey(game)){
            return cache.get(game);
        }else{
            int value=super.evaluate(game);
            cache.put(game, value);
            return value;
        }
    }
}