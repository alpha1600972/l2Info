package games.players;

/**
 * "NegamaxPlayer" est le nom de la classe permettant de selectionner le meilleur coup à jouer
 *elle ne depend ni de nim ni de tictactoe
 * @author diallo-sow
 * @version 1.0
 * @since 01-09-2022
 */

import games.genericgames.Game;

public class NegamaxPlayer implements Player{
    public NegamaxPlayer(){

    }
    /**
     * cette méthode retourne la valeur de la situation courante selon qu'elle soit une situation terminale ou non
     * @param game  Game representant la situation courante du jeu
     */
    public int evaluate(Game game){
            Player winner=game.getWinner();
            if((winner==game.getCurrentPlayer())){
                return 1;
            }
            else if((winner!=game.getCurrentPlayer())
            &&(winner!=null)){
                return -1;
            }
            else if((winner==null)&&(game.validMoves().isEmpty())){
            return 0;
            }
            Integer res=null;
            int v;
            for (int  move : game.validMoves()) {
                Game sPrime=game.copy();
                sPrime.execute(move);
                v=-evaluate(sPrime);
                if(res==null||v>res){
                    res=v;
                }
            }
            return res;
    }
   /**
* cette methode permet de determiner le meilleur coup à executer pour le joueur courant dans une situation non terminale
* @param game  Game representant la situation courante du jeu
*/
    @Override
    public int chooseMove(Game game){
        Integer bestValue=null;
        Integer bestMove=null;
        Game copy;
        int v;
        for (int move : game.validMoves()) {
            copy=game.copy();
            copy.execute(move);
            v=-evaluate(copy);
            if(bestValue==null||v>bestValue){
                bestValue=v;
                bestMove=move;
            }
        }
        return bestMove;
    }
}