package games.genericgames;

import java.util.ArrayList;

import games.players.Player;

public class TicTacToeWithHints extends TicTacToe{
    public TicTacToeWithHints(Player firstPlayer,Player secondPlayer){
        super(firstPlayer, secondPlayer);
    }
    /**
     * La methode qui montre au joueur courant le/les coup(s) que l'adversaire pourrait gagner immédiatement si c’était à son tour de jouer.
     * @return ArrayList un tableau des menaces pour le joueur courant.
     */
    public ArrayList<Integer> hints(){
        ArrayList<Integer> listHins=new ArrayList<Integer>();
        for (int move : this.validMoves()) {
            int row=super.getRow(move);
            int colum=super.getColum(move);
            if(super.getCurrentPlayer()==super.getFirstPlayer()){
                this.board[row][colum]="O";
                if(super.getWinner()==super.getSecondPlayer()){
                    listHins.add(move);
                }
            }
            else{
                this.board[row][colum]="X";
                if(super.getWinner()==super.getFirstPlayer()){
                    listHins.add(move);
                }
            }
            this.board[row][colum]="-";
        }
        for (int  move : listHins) {
            this.board[super.getRow(listHins.get(listHins.indexOf(move)))][super.getColum(listHins.get(listHins.indexOf(move)))]="?";
        }
        return listHins;  
    }
    /**
     * 
     */
    @Override
    public String situationToString(){
        String chaine=super.situationToString();
        if(this.hints().size()!=0 && super.getWinner()==null)
            chaine=super.situationToString()+"jouer le/les coup(s) "+this.hints()+" pour bloquer l'adversaire";
        return chaine;
    }
}
