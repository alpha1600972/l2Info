package games.genericgames;

/**
 * Cette classe permet de factoriser les deux jeux nim et morpion en particulier la
 * gestion des deux joueurs
 *elle implemente l'interface Game  
 
 * @author Mamadou Alpha Diallo & Mariama Saoudatou Sow, L2-Info, Université  Caen
 *         Normandie, France
 */

import games.players.Player;

public abstract class AbstractGame implements Game{
    private Player player1,player2;
    protected Player currentPlayer;
    public AbstractGame(Player firstPlayer,Player secondPlayer){
        this.player1=firstPlayer;
        this.player2=secondPlayer;
        this.currentPlayer=this.player1;
    }

    /**
    *cette methode permet de fretourner le joueur courant
    *elle implemente ici la methode getCurrentPlayer de l'interface Game
    * @param move entier qui represente un coup à executer
    */
    @Override
    public Player getCurrentPlayer() {
        return currentPlayer;
    }
     @Override
    public Player getFirstPlayer(){
        return this.player1;
    }
    @Override
    public Player getSecondPlayer(){
        return this.player2;
    }

    /**
    *cette methode permet de factoriser l'execution d'un coup des deux jeux nim et morpion
    * @param move entier qui represente un coup à executer
    */
    protected abstract void doExecute(int move);

    /**
     * cette méthode permet d'executer un coup en appelant la methode doExecute et en changeant le joueur courant
     *elle implemente la methode execute de l'interface Game
     * @param move entier qui  reprsente le coup à executer
     */
    @Override
    public void execute(int move){
        doExecute(move);
        if(this.player1==this.currentPlayer){
            this.currentPlayer=this.player2;
        }
        else{
            this.currentPlayer=this.player1;
        }

    }
}