package games.genericgames;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

import games.players.Player;
/**
 * TicTacToe est la classe principale du jeux de morpion
 *elle hérite de AbstractGame donc des attributs et méthodes de AbstractGame qui implemente l'interface Game
 * @author diallo-sow
 * @version 1.0
 * @since 
 */

public class TicTacToe extends AbstractGame{
    protected String[][] board;
    /**
     * le constructeur du TicTacToe
     * @param firstPlayer le nom du premier joueur 
     * @param secondPlayer le nom du deuxieme joueur
     */
    public TicTacToe(Player firstPlayer,Player secondPlayer){
        super(firstPlayer,secondPlayer);
        this.board = new String[3][3];
        for(int i=0;i<this.board.length;i++){
            for(int j=0;j<this.board[i].length;j++){
                this.board[i][j]="-";
            }
        }
    }

    public int getRow(int move) {
    	int row=move/3;
        return row;
    }
    
    public int getColum(int move) {
    	int colum=move%3;
        return colum;
    }
    
    public int getMove(int row,int colum){
    	int move=(3*row+colum);
        return move;

    }
    /**
     * retourne un numero d'objets contenant le joueur courant,
     *le tas d'allumettes courant et les coups valides pour une situation donnée
     */
    @Override
    public int hashCode(){
        return Objects.hash(this.getCurrentPlayer(),Arrays.deepHashCode(this.board));
    }
     /**
     * cette methode permet de tester si deux instances sont egales en fonction d'une situation donnée
     *retourne "true" si les instances sont egales et "false" sinon
     */
    @Override
    public boolean equals(Object o){
        if(this==o) return true;
        if(o==null && this!=null) return false;
        if(getClass()!=o.getClass()) return false;
        TicTacToe other=(TicTacToe) o;
        if((this.getCurrentPlayer()!=other.getCurrentPlayer())&&
        (!Arrays.deepEquals(this.board,other.board))) return false;
        return true;
    }
    /**
     * la methode qui permet de jouer un coup
     * @param move entier qui represente le coup a jouer
     */
    @Override
    public void doExecute(int move){
        int row=this.getRow(move);
        int colum=this.getColum(move);
        if(this.getFirstPlayer()==this.getCurrentPlayer()){
            this.board[row][colum]="X";
        }
        else{
            this.board[row][colum]="O";
        }
    }
    /**
     * la methode qui teste si un coup est valide
     * @param move entier qui represente un coup
     * @return boolean true si le coup est valide flase sinon
     */
    @Override
    public boolean isValid(int move) {
        boolean valide=true;
        int row=this.getRow(move);
        int colum=this.getColum(move);
        if((board[row][colum]=="X"||board[row][colum]=="O"||(!((Integer)move instanceof Integer)))){
            valide=false;
        }
        else{
            valide=true;
        }

        return valide;
    }
    /**
     * la methode qui listes tous les coups valides
     * @return ArrayList des coups valides
     */
    @Override
    public ArrayList<Integer> validMoves(){
        ArrayList<Integer> coupValide=new ArrayList<Integer>();
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                if(isValid(this.getMove(i,j)))
                coupValide.add(this.getMove(i,j));
            }
        }
        return coupValide;
    }
    /**
     * la methode qui verifie si un alignement indique une victoir pour un joueur donné
     * @param player String le nom du joueur
     * @param row   entier la ligne correspondante
     * @param colum  entier la colonne correspondante
     * @param deltaRow entier une direction selon la ligne
     * @param deltaColum entier la direction selon la colonne
     * @return true si un alignement est gagnant false sinon
     */
    public boolean wins(Player player,int row,int colum,int deltaRow,int deltaColum){
        boolean win=false;
        if(player==this.getFirstPlayer()){
            if((this.board[row][colum]=="X")&&(this.board[row+deltaRow][colum+deltaColum]=="X")&&(this.board[row+(2*deltaRow)][colum+(2*deltaColum)]=="X")){
                win=true;
            }
        }
        if(player==this.getSecondPlayer()){
            if((this.board[row][colum]=="O")&&(this.board[row+deltaRow][colum+deltaColum]=="O")&&(this.board[row+(2*deltaRow)][colum+(2*deltaColum)]=="O")){
                win=true;
            }
        }
        return win;
    }
    /**
     * la methode qui detemine qui est le vainqueur du jeux
     * @return String null si match nul ou partie non terminer, le nom du vaincaire sinon
     */
    @Override
    public Player getWinner(){
        Player winner=null;
        Player joueur;
        if (this.getCurrentPlayer()==this.getFirstPlayer()){
        	joueur= this.getSecondPlayer();
        }
        else{
        	joueur=this.getFirstPlayer();
        }
        if(wins(joueur, 0, 0, 1,1))
            winner=joueur;
        if(wins(joueur, 2, 0, -1, 1))
            winner=joueur;
        for(int i=0;i<this.board.length;i++){
            if(wins(joueur,i,0,0,1)){
                winner=joueur;
            }
        }
        for(int i=0;i<this.board.length;i++){
            if(wins(joueur,0,i,1,0)){
                winner=joueur;
            }
        }
        return winner;
    }
    /**
     * la methode qui teste si le jeux est fini 
     * @return boolean true si la partie est fini false sinon
     */
    @Override
    public boolean isOver(){
        boolean over=false;
        if(this.validMoves().size()==0){
            over=true;
        }
        if(this.getWinner()!=null){
            over=true;
        }
        return over;
    }

    /**
     * cette methode represente un coup
     * @param move entier qui est le coup du joueur
     */
    // @Override
    public String moveToString(int move) {
        return "\"("+(this.getRow(move)+1)+","+(this.getColum(move)+1)+")\" pour le coup:"+move;
    }
   /**
     * cette methode retourne une instance du jeu  de morpion selon la situation
     *elle copie tous les attributs en fonction de la situation courante
     */
    @Override
    public Game copy(){
        TicTacToe copy=new TicTacToe(super.getFirstPlayer(), super.getSecondPlayer());
        copy.board=new String[3][3];
        for(int i=0;i<this.board.length;i++){
            for(int j=0;j<this.board.length;j++){
                copy.board[i][j]=this.board[i][j];
            }
        }
        copy.currentPlayer=super.getCurrentPlayer();
        return copy;
    }

    /**
     * la methode qui represente la situation en cours du jeux
     * @return un Stirng representant l'ensemble des coups à jouer
     */

    @Override
    public String situationToString(){
        String chaine=" -----"+System.lineSeparator();
        for(int i=0;i<this.board.length;i++){
            for(int j=0;j<this.board[i].length;j++){
                chaine+="|"+this.board[i][j];
            }
            chaine+="|"+System.lineSeparator();
            chaine+=" -----"+System.lineSeparator();
        }
        chaine+="\n";
        System.out.println("hashCode: "+this.hashCode());
        return chaine;
    }
}
