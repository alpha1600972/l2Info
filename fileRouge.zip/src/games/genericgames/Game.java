package games.genericgames;

import games.players.Player;

import java.util.ArrayList;
public interface Game {
/**
* cette interface Game déclare toutes les méthodes permettant de gérer une partie de jeu 
* 
*/
public Player getCurrentPlayer();
public ArrayList<Integer> validMoves();
public Player getWinner();
public boolean isOver();
public boolean isValid(int move);
public String moveToString(int move);
public String situationToString();
public void execute(int move);
public Game copy();

public Player getFirstPlayer();
public Player getSecondPlayer();
}