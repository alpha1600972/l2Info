package games.genericgames;

import java.util.ArrayList;
import java.util.Objects;

import games.players.Player;

/**
 * "Nim" est le nom de la classe représentant le jeux et elle 
 * décrit les methodes et attributs du jeux 
 *elle hérite de AbstractGame donc des attributs et méthodes de AbstractGame qui implemente l'interface Game
 * @author diallo-sow
 * @version 1.0
 * @since 01-09-2022
 */
public class Nim extends AbstractGame{
    private int n,k;
    private int nbCurrent;
    /**
     * Le constructeur du Nim
     * @param sizeInit entier representant la taille initiale du tas
     * @param nbMax    entier representant le nombre maximale d'allumettes qu'un joueur peut retirer
     * @param player1  Player representant le nom du premier joueur
     * @param player2  Player representant le nom du deuxieme joueur
     */
    public Nim(int sizeInit,int nbMax,Player player1,Player player2){
        super(player1, player2);
        this.n=sizeInit;
        this.k=nbMax;
        this.nbCurrent=sizeInit;
    }

    public int getK() {
        return k;
    }
    
    public int getInitialNbMatches(){
        return this.n;
    }

    public int getCurrentNbMatches(){
        return this.nbCurrent;
    }
     /**
     * retourne un numero d'objets contenant le joueur courant,
     *le tas d'allumettes courant et les coups valides pour une situation donnée
     */
    @Override
    public int hashCode(){
        return Objects.hash(this.getCurrentPlayer(),
        this.getCurrentNbMatches(),this.validMoves());
    }
    /**
     * cette methode permet de tester si deux instances sont egales en fonction d'une situation donnée
     *retourne "true" si les instances sont egales et "false" sinon
     */
    @Override
    public boolean equals(Object o){
        if(this==o) return true;
        if(o==null) return false;
        if(getClass()!=o.getClass()) return false;
        Nim other=(Nim) o;
        if((this.getCurrentPlayer()!=other.getCurrentPlayer())&&
        (this.getCurrentNbMatches()!=other.getCurrentNbMatches())) return false;
        return true;
    }
    /**
     * la methode qui represente la situation en cours du jeux
     * @return un String informant le nombre d'allumette qui reste 
     */
    // @Override
    public String situationToString(){
        return "Il reste "+this.nbCurrent+" allumettes";
    }
    /**
     * la methode qui permet au joueur courant de joueur un coup et ensuite redonner la main a son adverssaire
     * 
     * @param move entier qui est le coup du joueur
     */
    @Override
    public void doExecute(int move){
        this.nbCurrent=this.getCurrentNbMatches()-move;
    }
    /**
     * la methode qui test si le coup saisie est valide
     * @param move entier represantant le coup
     * @return boolean true si le coup et valide et false sinon
     */
    @Override
    public boolean isValid(int move){
        boolean validMove=false;
        if((move>0)&&(move<=this.k)&&(move<=getCurrentNbMatches())){
            validMove=true;
        }
        else{
            validMove=false;
        }
        return validMove;
    }
    /**
     * 
     */
    @Override
    public ArrayList<Integer> validMoves(){
        ArrayList<Integer> movesValides=new ArrayList<Integer>();
        for(int i=1;i<=this.getInitialNbMatches();i++){
            if(isValid(i)){
                movesValides.add(i);   
            }
        }
        return movesValides; 
    }
    /**
     * cette methode represente un coup
     * @param move entier qui est le coup du joueur
     */
    @Override
    public String moveToString(int move){
        return "coup:"+move;
    }
    /**
     * cette methode teste si le jeux est terminer ou pas
     * @return boolean true si le jeux est terminer false sinon
     */
    @Override
    public boolean isOver(){
        boolean end=false;
        if(this.getCurrentNbMatches()==0)
            end=true;
        return end;
    }
    /**
     * la methode qui determine le vainqueur
     * @return Player null si le jeux ne pas fini le nom du gagnant si non
     */
    @Override
    public Player getWinner(){
        Player winner;
        if(!isOver())
            return null;
        if(getCurrentPlayer()==this.getFirstPlayer())
            winner=this.getFirstPlayer();
        else
            winner=this.getSecondPlayer();
        return winner;
    }
    /**
     * cette methode retourne une instance du jeu de nim selon la situation
     *elle copie tous les attributs en fonction de la situation courante
     */
    @Override
    public Game copy(){
        Nim copy=new Nim(this.getInitialNbMatches(), this.getK(), this.getFirstPlayer(), this.getSecondPlayer());
        copy.nbCurrent=this.getCurrentNbMatches();
        copy.currentPlayer=super.getCurrentPlayer();
        return copy;
    }
}
