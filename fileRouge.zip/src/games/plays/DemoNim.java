package games.plays;


import java.util.Random;
import java.util.Scanner;

import games.genericgames.Game;
import games.genericgames.Nim;
import games.players.Human;
// import games.players.NegamaxPlayer;
// import games.players.NegamaxPlayerWithCache;
import games.players.Player;
import games.players.RandomPlayer;

public class DemoNim{
    public static void main(String[] args) {
        int n=0,k=0;
        Scanner scan=new Scanner(System.in);
        try {
            System.out.println("Saisir la taille initiale du tas");
             n=scan.nextInt();
            System.out.println("Saisir nombre maximal d’allumettes qu’un joueur peut retirer");
             k=scan.nextInt();
        } catch (Exception e) {
           System.out.println("\nla taille et/ou le nombre maximal doit être des entiers\n");
           System.exit(2);
        }
        Random rand=new Random(123);
        // NegamaxPlayer player1=new NegamaxPlayer();
        // NegamaxPlayer player2=new NegamaxPlayer();
        // NegamaxPlayer player1=new  NegamaxPlayerWithCache();
        // NegamaxPlayer player2=new  NegamaxPlayerWithCache();
        Player player1=new Human("moi", scan);
        // Player player2=new Human(name, scan);
        // Player player1=new RandomPlayer(rand);
        Player player2=new RandomPlayer(rand);

        Game nim=new Nim(n, k,player1,player2);
        DemoNim.presentation((Nim)nim);
        Orchestrator orchestrator= new Orchestrator(nim);
        orchestrator.play();
        scan.close();
    }
    public static void presentation(Nim game){
        System.out.println("\tPresentation du jeux\n");
        System.out.println("\tPremier joueur: "+game.getFirstPlayer());
        System.out.println("\tDeuxieme joueur: "+game.getSecondPlayer());
        System.out.println("\tTaille initiale du tas: "+game.getInitialNbMatches());
        System.out.println("\tle nombre maximal d’allumettes qu’un joueur peut retirer: "+game.getK()+"\n");
    }
}

