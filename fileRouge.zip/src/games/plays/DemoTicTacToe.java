package games.plays;

import java.util.Random;
import java.util.Scanner;

import games.genericgames.Game;
import games.genericgames.TicTacToe;
import games.genericgames.TicTacToeWithHints;
import games.players.Human;
import games.players.NegamaxPlayer;
import games.players.NegamaxPlayerWithCache;
import games.players.Player;
import games.players.RandomPlayer;

    public class DemoTicTacToe{
        public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Voulez vous jouer avec indice?  \n \t oui/non");
        String answer=scan.nextLine();
        Game jx;
        Random rand=new Random(123);
        // Player player1=new NegamaxPlayer();
        Player player2=new NegamaxPlayer();
        // Player player1=new  NegamaxPlayerWithCache();
        // Player player2=new  NegamaxPlayerWithCache();
        Player player1=new Human("moi", scan);
        // Player player2=new Human(name, scan);
        // Player player1=new RandomPlayer(rand);
        // Player player2=new RandomPlayer(rand);
        if(answer.equalsIgnoreCase("oui")){
            jx= new TicTacToeWithHints(player1, player2);
       }
       else{
            jx=new TicTacToe(player1, player2);
       }
        DemoTicTacToe.presentation(jx);
        Orchestrator orchestrator= new Orchestrator(jx);
        orchestrator.play();
        scan.close();
    }

    public static void presentation(Game game){
        System.out.println("\tPresentation du jeux\n");
        System.out.println("\tPremier joueur: "+game.getFirstPlayer());
        System.out.println("\tDeuxieme joueur: "+game.getSecondPlayer());
        System.out.println("\tSituation du jeux:\n"+game.situationToString());
    }
}