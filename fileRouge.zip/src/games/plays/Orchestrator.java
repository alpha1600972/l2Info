package games.plays;

/**
 * "Orchestrator" est le nom de la classe permettant d'arbitrer une partie
 *elle ne depend ni de nim ni de tictactoe
 * @author diallo-sow
 * @version 1.0
 * @since 01-09-2022
 */

import games.genericgames.Game;
import games.players.Player;

public class Orchestrator{
    protected Game game;
    public Orchestrator(Game game){
        this.game=game;
    }
    /**
     *cette methode permet de gerer une partie de jeu(nim ou morpion)
     */
    public void play() throws IllegalStateException{
        while(!this.game.isOver()){
            Player player=this.game.getCurrentPlayer();
            System.out.println("le joueur encour:"+this.game.getCurrentPlayer());
                int res= player.chooseMove(this.game);
                this.game.execute(res);
                System.out.println(res);
            System.out.println(this.game.situationToString());
        }
        System.out.println("Winner:"+this.game.getWinner());
    }
}