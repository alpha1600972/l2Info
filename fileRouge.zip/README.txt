Deuxieme partie du Controle Contunie (genericgame,players et plays)

Membre de groupe:
-DIALLO Mamadou Alpha 22107614
-SOW Mariama Saoudatou 22209828

 toutes les partie du projet sont realiser.

Hierachie et packetage du porjet
dans le dossier src on retrouve les packages contenant les differente partie du projet
--game.genericgame:
    -AbstractGame.java (classe)
    -Game.java (Interface)
    -Nim.java (classe)
    -TicTacToe (classe)
    -TicTacToeWithHints.java (classe)
    -Test.java (classe)
--game.players:
    -Humain.java (classe)
    -NegamaxPlayer.java (classe)
    -NegamaxPlayerWithCache.java (classe)
    -RandomPlayer.java (classe)
    -Test.java (class)
    -Player.java (Interface)
--game.plays:
    -Orchestrator.java (classe)
    -DemoNim.java (classe)
    -DemoTicTacToe.java (classe)
    -Test.java (classe)

l'execution du projet

 Les classes executable du projet sont: DemoNim et DemoTicTacToe
    Apartir du repertoir src on peut saisir ces commandes:
    Pour la compilation:
        -javac -d ../build game/plays/DemoNim.java (pour le jeux Nim)
        -javac -d ../build game/plays/DemoTicTacToe.java (pour le jeux TicTacToe)
    une fois la compilation est reussi on peut les executer avec ces commandes:
        -java -cp ../build game.plays.DemoNim
        -java -cp ../build game.plays.DemoTicTacToe
Remarque:
Tous les joueurs sont declare a l'interieur des classes executable,mais seulement deux sont utiliser pour l'exemple.
Pour pouvoir utiliser les autres vous devez commenter ceux utilisé et enlever les commentaire sur les qulles vous vouler utliser